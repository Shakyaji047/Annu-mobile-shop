# Annu-mobile-shop
A simple and responsive website for a Mobile Accessories Shop. It includes product showcase (mobile covers, chargers, earphones, etc.), pricing details, and direct WhatsApp order option. Built using HTML &amp; CSS, hosted free with GitHub Pages.
